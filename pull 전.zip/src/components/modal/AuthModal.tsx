function AuthModal(msg:string){
    return(
        <>
        </>
    );
}
export default AuthModal;