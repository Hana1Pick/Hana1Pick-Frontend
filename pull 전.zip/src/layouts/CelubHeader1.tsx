import arrow from'../assets/images/celub/arrow.png';
function CelubHeader1(){
    return(
        <>
            <div id="celubHeader1">
                <img id="arrow_loc" src={arrow} />
            </div>
        </>
    );
}
export default CelubHeader1;