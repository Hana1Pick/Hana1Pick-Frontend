function MainPage(){
    <script>
    
        
    </script>
    return(
        <>
            <div>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                <h1>
                    여기는 메인페이지
                </h1>
                <div>
                    <button id="basicBtn1">Click!</button>
                </div>
            </div>
        </>
    );
}

export default MainPage;